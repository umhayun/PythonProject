# 두수를 입력받아 연산하는 계산기 모듈
#Sum(a,b) , Sub(a,b), Mul(a,b), Div(a,b)함수를 정의해주세요

def Sum(a,b):
    return a+b
def Sub(a,b):
    return a-b
def Mul(a,b):
    return a*b
def Div(a,b):
    return a/b