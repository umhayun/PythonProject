def Div(a,b):
    return a/b