def Mul(a,b):
    return a*b