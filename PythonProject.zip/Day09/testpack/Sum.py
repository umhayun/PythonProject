def Sum(a,b):
    return a+b