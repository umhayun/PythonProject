def Sub(a,b):
    return a-b